var initCase = function() {
	console.log("case works");
};

module.exports = {
	init: initCase
}
